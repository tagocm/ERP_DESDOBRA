alter table addresses add column deleted_at timestamp with time zone default null;
