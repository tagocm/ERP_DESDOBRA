-- Force Schema Cache Reload for PostgREST
NOTIFY pgrst, 'reload schema';
