-- Force PostgREST schema reload
NOTIFY pgrst, 'reload schema';
