NOTIFY pgrst, 'reload schema';
