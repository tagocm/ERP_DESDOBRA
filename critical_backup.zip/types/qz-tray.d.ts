declare module 'qz-tray' {
    const qz: any;
    export default qz;
}
